import { Constants } from './constants';
import { CaptchaDataFromRequest } from './interface';
import { YesCaptchaSolver } from './providers/yescaptcha';
import { Utils } from './utils';

let yesCaptchaClient: YesCaptchaSolver | null = null;

if (process.env.YES_CAPTCHA_API_KEY) {
console.log('พบ API Key ของ YesCaptcha เปิดใช้งานการแก้แคปช่าแล้ว');
	yesCaptchaClient = new YesCaptchaSolver(process.env.YES_CAPTCHA_API_KEY);
}

export function solveCaptcha(data: CaptchaDataFromRequest): Promise<string> {
// ! ใช้งานได้
// return Utils.askQuestion("กรุณาป้อนคีย์แคปช่าด้วยตนเอง: ");
// TODO: เพิ่มการแก้แคปช่าด้วยบริการจากภายนอก เช่น YesCaptcha
// ! อัตราข้อผิดพลาดของ YesCaptcha กับ Discord สูงมาก
// (ตามที่ระบุไว้ในเอกสาร) ไม่ควรใช้ เพราะมักส่งข้อผิดพลาด 10008 กลับมา
	if (yesCaptchaClient) {
		return yesCaptchaClient
			.hcaptcha(data.captcha_sitekey, 'https://discord.com', {
				rqdata: data.captcha_rqdata,
				isInvisible: false,
				userAgent: Constants.USER_AGENT,
			})
			.then((result) => result.gRecaptchaResponse);
	}
return Promise.reject(new Error('ยังไม่ได้ติดตั้งระบบแก้แคปช่า'));
}
